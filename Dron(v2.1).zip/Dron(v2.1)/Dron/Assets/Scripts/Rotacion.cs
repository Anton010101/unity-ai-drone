﻿using UnityEngine;

public class Rotacion : MonoBehaviour
{
    void Update()
    {
        this.transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);
    }
}
