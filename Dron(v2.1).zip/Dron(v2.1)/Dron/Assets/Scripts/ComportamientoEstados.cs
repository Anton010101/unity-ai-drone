﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Ejemplo de un comportamiento automático para el agente (basado en modelos)
public class ComportamientoEstados : MonoBehaviour {

	private Sensores sensor;
	private Actuadores actuador;

    // Variables para gestionar el radio de visión, el de ataque y la velocidad
    public float visionRadius;
    public float speed;

    // Variable para guardar al jugador
    GameObject player;

    // Variable para guardar la posición inicial
    Vector3 initialPosition;

    // Animador y cuerpo cinemático con la rotación en Z congelada
    Animator anim;
    Rigidbody rb2d;
    private enum Percepcion {NoParedCerca=0, ParedCerca=1, NoPersonaCerca=2, PersonaCerca=3}; // Lista predefinida de posibles percepciones con los sensores
	private enum Estado {Avanzar=0, Detenerse=1, Seguir=2}; // Lista de estados para la maquina de estados y tabla de transiciones
	private Estado estadoActual;
	private Percepcion percepcionActual;

    private Rigidbody rb;
    void Start(){
		sensor = GetComponent<Sensores>();
		actuador = GetComponent<Actuadores>();
		estadoActual = Estado.Avanzar;

        // Recuperamos al jugador gracias al Tag
        player = GameObject.FindGameObjectWithTag("Player");

        // Guardamos nuestra posición inicial
        initialPosition = transform.position;

        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody>();
    }

	void FixedUpdate() {
		if(sensor.Bateria() <= 0)
			return;

		percepcionActual = PercibirMundo();
		estadoActual = TablaDeTransicion(estadoActual, percepcionActual);
		AplicarEstado(estadoActual);
	}

    // A partir de este punto se representa un agente basado en modelos.
    // La idea es similar a crear una máquina de estados finita donde se hacen las siguientes consideraciones:
    // - El alfabeto es un conjunto predefinido de percepciones hechas con sensores del agente
    // - El conjunto de estados representa un conjunto de métodos con acciones del agente
    // - La función de transición es un método
    // - El estado inicial se inicializa en Start()
    // - El estado final es opcional (pero recomendable de indicar)

    // Tabla de transición que representa el conjunto de reglas
    // -------------------------------------------------------------------------------
    // | Estado\Percepcion | paredCerca | !paredCerca | personaCerca | !personaCerca |
    // |-------------------|------------|-------------|--------------|---------------|
    // | Avanzar           | Detenerse  | Avanzar     | Seguir       | Avanzar       |
    // |-------------------|------------|-------------|--------------|---------------|
    // | Detenerse         | Detenerse  | Detenerse   | Detenerse    | Detenerse     |
    // |-------------------|------------|-------------|--------------|---------------|
    // | Seguir            | Detenerse  | Seguir      | Seguir       | Avanzar       |
    // |-------------------|------------|-------------|--------------|---------------|
    // |            |  |      |     |     |
    // |-------------------|------------|-------------|--------------|---------------|
    // |          |   |    |
    // |-------------------|------------|-------------|
    // |-------------------|------------|-------------|
    // |           |  |      |
    // |-------------------|------------|-------------|
    // |          |  |    |
    // ------------------------------------------------
    Estado TablaDeTransicion(Estado estado, Percepcion percepcion){
		switch(estado){
			case Estado.Avanzar:
				switch(percepcion){
					case Percepcion.ParedCerca:
						estado = Estado.Detenerse;
						break;
					case Percepcion.NoParedCerca:
						estado = Estado.Avanzar;
						break;
				}
				break;
			case Estado.Detenerse:
				switch(percepcion){
					case Percepcion.ParedCerca:
						estado = Estado.Detenerse;
						break;
					case Percepcion.NoParedCerca:
						estado = Estado.Detenerse;
						break;
				}
				break;
            case Estado.Seguir:
                switch (percepcion)
                {
                    case Percepcion.PersonaCerca:
                        estado = Estado.Seguir;
                        break;
                    case Percepcion.NoPersonaCerca:
                        estado = Estado.Avanzar;
                        break;
                }
                break;
        }
		return estado;
	}

	// Representación de los ESTADOS como métodos

	// El estado AVANZAR significa moverse hacia adelante siempre.
	void Avanzar(){
		actuador.Flotar();
		actuador.Adelante();
	}
	// El estado DETENERSE representa mantenerse en el mismo punto
	void Detenerse(){
		actuador.Flotar();
		actuador.Detener();
	}

    void Seguir()
    {
        actuador.Flotar();
        actuador.Adelante();
        

    }
    // Usar sensores para determinar el tipo de percepción actual
    Percepcion PercibirMundo() {
        Percepcion percepcionActual = Percepcion.NoParedCerca;
        if (sensor.CercaDePared())
            percepcionActual = Percepcion.ParedCerca;
        else
            percepcionActual = Percepcion.NoParedCerca;
        return percepcionActual;

    }

	// Aplicar el estado actual, i.e, mandar a llamar al método del estado dado como parámetro
	void AplicarEstado(Estado estado){
		switch(estado){
			case Estado.Avanzar:
				Avanzar();
				break;
			case Estado.Detenerse:
				Detenerse();
				break;
            case Estado.Seguir:
                Seguir();
                break;
			default:
				Detenerse();
				break;

		}
	}

    private void Update()
    {

        // Por defecto nuestro target siempre será nuestra posición inicial
        Vector3 target = initialPosition;

        // Comprobamos un Raycast del enemigo hasta el jugador
        RaycastHit2D hit = Physics2D.Raycast(
            transform.position,
            player.transform.position - transform.position,
            visionRadius,
            1 << LayerMask.NameToLayer("Default")
        // Poner el propio Enemy en una layer distinta a Default para evitar el raycast
        // También poner al objeto Attack y al Prefab Slash una Layer Attack 
        // Sino los detectará como entorno y se mueve atrás al hacer ataques
        );

        // Aquí podemos debugear el Raycast
        Vector3 forward = transform.TransformDirection(player.transform.position - transform.position);
        Debug.DrawRay(transform.position, forward, Color.red);

        // Si el Raycast encuentra al jugador lo ponemos de target
        if (hit.collider != null)
        {
            if (hit.collider.tag == "Player")
            {
                target = player.transform.position;
            }
        }

        // Calculamos la distancia y dirección actual hasta el target
        float distance = Vector3.Distance(target, transform.position);
        Vector3 dir = (target - transform.position).normalized;

        // En caso contrario nos movemos hacia él
 

        // Una última comprobación para evitar bugs forzando la posición inicial
        if (target == initialPosition && distance < 0.02f)
        {
            transform.position = initialPosition;

        }
        else
        {
            rb.MovePosition(transform.position + (dir * speed * Time.deltaTime));

        }

        // Y un debug optativo con una línea hasta el target
        Debug.DrawLine(transform.position, target, Color.green);
    }


    void OnDrawGizmosSelected()
    {

        Gizmos.color = Color.yellow;
        //Gizmos.DrawWireSphere(transform.position, visionRadius);

    }
}

